import asyncio
import random

import pygame


GRID_SIZE = 20
CELL_SIZE = 25
BOARD_SIZE = GRID_SIZE * CELL_SIZE
SCREEN_SIZE = 620
BOARD_LEFT = (SCREEN_SIZE - BOARD_SIZE) // 2
BOARD_TOP = 60
FPS = 60
MOVE_INTERVAL_MS = 100

BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
DARK_GREEN = (0, 180, 0)

DIRECTIONS = {
    pygame.K_LEFT: (-1, 0),
    pygame.K_a: (-1, 0),
    pygame.K_RIGHT: (1, 0),
    pygame.K_d: (1, 0),
    pygame.K_UP: (0, -1),
    pygame.K_w: (0, -1),
    pygame.K_DOWN: (0, 1),
    pygame.K_s: (0, 1),
}


def random_snack(body):
    free_cells = [
        (x, y)
        for x in range(GRID_SIZE)
        for y in range(GRID_SIZE)
        if (x, y) not in body
    ]
    return random.choice(free_cells) if free_cells else None


class SnakeGame:
    def __init__(self):
        self.reset()

    def reset(self):
        self.body = [(10, 10)]
        self.direction = (0, 1)
        self.next_direction = self.direction
        self.snack = random_snack(self.body)
        self.game_over = False
        self.won = False

    def change_direction(self, direction):
        if direction != (-self.direction[0], -self.direction[1]):
            self.next_direction = direction

    def step(self):
        self.direction = self.next_direction
        x, y = self.body[0]
        dx, dy = self.direction
        next_head = ((x + dx) % GRID_SIZE, (y + dy) % GRID_SIZE)
        eating = next_head == self.snack
        occupied = self.body if eating else self.body[:-1]

        if next_head in occupied:
            self.game_over = True
            return

        self.body.insert(0, next_head)
        if eating:
            self.snack = random_snack(self.body)
            if self.snack is None:
                self.game_over = True
                self.won = True
        else:
            self.body.pop()


def draw_game(screen, game, score_font, message_font):
    screen.fill(BLACK)

    score = score_font.render(f"Score: {len(game.body) - 1}", True, WHITE)
    screen.blit(score, score.get_rect(center=(SCREEN_SIZE // 2, 28)))

    board_rect = pygame.Rect(BOARD_LEFT, BOARD_TOP, BOARD_SIZE, BOARD_SIZE)
    pygame.draw.rect(screen, BLACK, board_rect)
    for grid_line in range(GRID_SIZE + 1):
        offset = grid_line * CELL_SIZE
        pygame.draw.line(
            screen,
            WHITE,
            (BOARD_LEFT + offset, BOARD_TOP),
            (BOARD_LEFT + offset, BOARD_TOP + BOARD_SIZE),
        )
        pygame.draw.line(
            screen,
            WHITE,
            (BOARD_LEFT, BOARD_TOP + offset),
            (BOARD_LEFT + BOARD_SIZE, BOARD_TOP + offset),
        )

    if game.snack is not None:
        x, y = game.snack
        pygame.draw.rect(
            screen,
            GREEN,
            (BOARD_LEFT + x * CELL_SIZE + 1, BOARD_TOP + y * CELL_SIZE + 1,
             CELL_SIZE - 2, CELL_SIZE - 2),
        )

    for index, (x, y) in enumerate(game.body):
        color = RED if index else DARK_GREEN
        pygame.draw.rect(
            screen,
            color,
            (BOARD_LEFT + x * CELL_SIZE + 1, BOARD_TOP + y * CELL_SIZE + 1,
             CELL_SIZE - 2, CELL_SIZE - 2),
        )

    if game.game_over:
        message = "You win!" if game.won else "Game over!"
        label = message_font.render(f"{message} Press Space to restart", True, WHITE)
        label_rect = label.get_rect(center=(SCREEN_SIZE // 2, SCREEN_SIZE // 2))
        background = label_rect.inflate(24, 18)
        pygame.draw.rect(screen, BLACK, background)
        screen.blit(label, label_rect)
    else:
        controls = score_font.render("Arrow keys or WASD to move", True, WHITE)
        screen.blit(controls, controls.get_rect(center=(SCREEN_SIZE // 2, 590)))

    pygame.display.flip()


async def main():
    pygame.init()
    screen = pygame.display.set_mode((SCREEN_SIZE, SCREEN_SIZE))
    pygame.display.set_caption("Snake")
    score_font = pygame.font.SysFont("monospace", 18)
    message_font = pygame.font.SysFont("monospace", 22)
    clock = pygame.time.Clock()
    game = SnakeGame()
    move_accumulator = 0
    running = True

    while running:
        await asyncio.sleep(0)
        elapsed_ms = min(clock.tick(FPS), 250)
        move_accumulator += elapsed_ms

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if game.game_over and event.key == pygame.K_SPACE:
                    game.reset()
                    move_accumulator = 0
                elif not game.game_over and event.key in DIRECTIONS:
                    game.change_direction(DIRECTIONS[event.key])
            elif event.type == pygame.MOUSEBUTTONDOWN and game.game_over:
                game.reset()
                move_accumulator = 0

        while move_accumulator >= MOVE_INTERVAL_MS and not game.game_over:
            game.step()
            move_accumulator -= MOVE_INTERVAL_MS

        draw_game(screen, game, score_font, message_font)

    pygame.quit()


if __name__ == "__main__":
    asyncio.run(main())

# Snake

This private repository contains the original Pygame game and a browser-compatible version. The playable web build is published separately.

## Play

- Use the **arrow keys** or **WASD** to move.
- The snake wraps around the edges.
- Eat the green food to grow and increase your score.
- Avoid running into yourself.
- Press **Space** or click after a game ends to restart.

The original game is preserved as `legacy/snakegame.py`. The browser entry point replaces its desktop-only Tkinter game-over dialog with an in-game restart screen.

## Run locally

Use Python 3.11 and install the dependencies:

```sh
python -m pip install -r requirements.txt
python main.py
```

## Build and test in a browser

```sh
python -m pygbag --build --app_name "Snake" --title "Snake" --package "snakegame-v2" .
python .github/scripts/patch_pygbag_output.py
python -m http.server 8000 --directory build/web
```

Open <http://localhost:8000> in a modern browser.
